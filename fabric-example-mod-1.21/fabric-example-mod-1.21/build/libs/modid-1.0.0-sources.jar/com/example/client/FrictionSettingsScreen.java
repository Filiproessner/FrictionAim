package com.example.client;

import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_357;
import net.minecraft.class_4185;
import net.minecraft.class_437;

public class FrictionSettingsScreen extends class_437 {
    public FrictionSettingsScreen() {
        super(class_2561.method_43470("Friction Settings"));
    }

    @Override
    protected void method_25426() {
        // Der Slider
        this.method_37063(new class_357(this.field_22789 / 2 - 100, this.field_22790 / 2 - 20, 200, 20, class_2561.method_43470("Friction"), (double) FrictionConfig.frictionFactor) {
            {
                this.method_25346();
            }

            @Override
            protected void method_25346() {
                this.method_25355(class_2561.method_43470("Speed auf Gegner: " + (int)(FrictionConfig.frictionFactor * 100) + "%"));
            }

            @Override
            protected void method_25344() {
                FrictionConfig.frictionFactor = (float) this.field_22753;
            }
        });

        // Der Button
        this.method_37063(class_4185.method_46430(class_2561.method_43470("Fertig"), button -> this.method_25419())
                .method_46434(this.field_22789 / 2 - 100, this.field_22790 / 2 + 20, 200, 20)
                .method_46431());
    }

    @Override
    public void method_25394(class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
        // In 1.21 nutzt man renderTransparentBackground für das normale Menü-Verwischen
        this.method_52752(guiGraphics);

        // Falls du den dunklen Hintergrund ohne Blur willst, nutze:
        // guiGraphics.fillGradient(0, 0, this.width, this.height, -1072689136, -804253680);

        super.method_25394(guiGraphics, mouseX, mouseY, partialTick);
    }
}