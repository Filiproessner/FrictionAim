package com.example.client;

import com.example.client.FrictionConfig;
import com.example.client.FrictionSettingsScreen;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.class_2561;
import net.minecraft.class_304;
import net.minecraft.class_3675;
import org.lwjgl.glfw.GLFW;

public class ExampleModClient implements ClientModInitializer {

	@Override
	public void onInitializeClient() {
		// Hier nutzen wir jetzt die Konstante MISC aus dem Category Record
		// Der Pfad ist KeyMapping.Category.MISC

		class_304 toggleKey = KeyBindingHelper.registerKeyBinding(new class_304(
				"key.friction.toggle",
				class_3675.class_307.field_1668,
				GLFW.GLFW_KEY_H,
				class_304.class_11900.field_62556 // <--- DAS ist die Lösung!
		));

		class_304 configKey = KeyBindingHelper.registerKeyBinding(new class_304(
				"key.friction.menu",
				class_3675.class_307.field_1668,
				GLFW.GLFW_KEY_K,
				class_304.class_11900.field_62556
		));

		ClientTickEvents.END_CLIENT_TICK.register(client -> {
			if (client.field_1724 == null) return;

			// In deiner KeyMapping.class Datei steht die Methode 'consumeClick()'
			while (toggleKey.method_1436()) {
				FrictionConfig.enabled = !FrictionConfig.enabled;
				client.field_1724.method_7353(class_2561.method_43470("Friction: " + (FrictionConfig.enabled ? "§aAN" : "§cAUS")), true);
			}

			while (configKey.method_1436()) {
				client.method_1507(new FrictionSettingsScreen());
			}
		});
	}
}