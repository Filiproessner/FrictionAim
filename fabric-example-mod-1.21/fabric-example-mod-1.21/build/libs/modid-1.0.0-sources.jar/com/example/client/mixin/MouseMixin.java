package com.example.client.mixin;

import com.example.client.FrictionConfig;
import net.minecraft.class_1657;
import net.minecraft.class_239;
import net.minecraft.class_310;
import net.minecraft.class_312;
import net.minecraft.class_3966;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

@Mixin(class_312.class)
public class MouseMixin {
    // In Mojang Mappings heißt das Feld meistens 'minecraft' und die Klasse 'Minecraft'
    @Shadow @Final private class_310 minecraft;

    // Falls 'updateMouse' rot ist, heißt die Methode in Mojang Mappings 'turnPlayer'
    // Wir versuchen es mit 'turnPlayer', das ist die gängige Methode für 1.21
    @ModifyVariable(method = "turnPlayer", at = @At("STORE"), ordinal = 2)
    private double applyFriction(double d) {
        // In Mojang Mappings heißt das Ziel 'hitResult'
        if (FrictionConfig.enabled && minecraft.field_1765 != null && minecraft.field_1765.method_17783() == class_239.class_240.field_1331) {
            if (((class_3966)minecraft.field_1765).method_17782() instanceof class_1657) {
                return d * FrictionConfig.frictionFactor;
            }
        }
        return d;
    }
}