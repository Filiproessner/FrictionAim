package com.example.client; // <--- DEIN PAKETNAME HIER ANPASSEN

public class FrictionConfig {
    public static boolean enabled = true;
    public static double frictionFactor = 0.5; // Standard: 50% Speed
}